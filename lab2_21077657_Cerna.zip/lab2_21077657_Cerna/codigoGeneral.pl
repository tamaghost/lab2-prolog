
option(CodeOp, Mensaje, ChatbotCodeLink, InitialFlowCodeLink, Keyword,[CodeOp, Mensaje, ChatbotCodeLink, InitialFlowCodeLink, Keyword]).

getMensajeOption([_, Mensaje, _, _, _], Mensaje).

getKeywordOption([_, _, _, _, ListKeywords], ListKeywords).

getChatbotCodeLinkOption([_, _, ChatbotCodeLink, _, _], ChatbotCodeLink).

getInitialFlowCodeLinkOption([_, _, _, InitialFlowCodeLink, _], InitialFlowCodeLink).

%funciona
/*VERIFICAR QUE LAS OPCIONES NO SE REPITAN*/
flow(Id, NameMsg, Option,[Id, NameMsg, Option]).
%funciona
getOptionFlow(Flow, Option) :-
    flow(_, _, Option, Flow).
%funciona
setOptionFlow(Flow,NewOption,FlowNew):-
    flow(IdF,NameMsgF,_,Flow),
    flow(IdF,NameMsgF,NewOption,FlowNew).
%funciona
flowAddOption(Flow1,Option,Flow2):-
    getOptionFlow(Flow1,Opciones),
    member(Option,Opciones),
    false.
flowAddOption(Flow1,Option,Flow2):-
    getOptionFlow(Flow1,Opciones),
    \+member(Option,Opciones),
    ListaModFP = [Option|Opciones],
    setOptionFlow(Flow1,ListaModFP,Flow2).
%funciona
/*VERIFICAR QUE LAS OPCIONES NO SE REPITAN*/
chatbot(ChatbotID, Name, WelcomeMessage, StartFlowId, Flows,[ChatbotID, Name, WelcomeMessage, StartFlowId, Flows]).

getIDChatbot(Chatbot,ChatbotID):-
    chatbot(ChatbotID,_,_,_,_,Chatbot).

%funciona
getFlowChatbot(Chatbot, Flow):-
    chatbot(_,_,_,_,Flow,Chatbot).
%funciona
setFlowChatbot(Chatbot,NewFlow,NewChatbot):-
    chatbot(ChatbotIDC, NameC, WelcomeMessageC, StartFlowIdC, _,Chatbot),
    chatbot(ChatbotIDC, NameC, WelcomeMessageC, StartFlowIdC, NewFlow,NewChatbot).
%funciona
chatbotAddFlow(Chatbot1, Flow, Chatbot2) :-
    getFlowChatbot(Chatbot1, ListFlow),
    member(Flow, ListFlow),
    Chatbot2 = Chatbot1.
chatbotAddFlow(Chatbot1, Flow, Chatbot2) :-
    getFlowChatbot(Chatbot1, ListFlow),
    \+ member(Flow, ListFlow),
    append(ListFlow, [Flow], ListaModCF),
    setFlowChatbot(Chatbot1, ListaModCF, Chatbot2).

%funciona
%***implementar chathistory a system
/*ARREGLAR GETTER Y SETTER DE SYSTEM*/
system(Users, Name, InitialChatbotCodeLink, Chatbot, [Users, Name, InitialChatbotCodeLink, Chatbot]).
/*revisar los gets de system*/


%funciona
getChatbotSystem(System, Chatbot):-
    system(_,_,_,Chatbot,System).
%funciona
setSystemChatbot(System,NewChatbot,NewSystem):-
    system(UsersS, NameS, InitialChatbotCodeLinkS,_, System),
    system(UsersS, NameS, InitialChatbotCodeLinkS, NewChatbot, NewSystem).

listID([],ListaId).
listID([Cabeza|Cola],ListaId):-
    getIDChatbot(Cabeza,ListChbtId),
    listaMensajeOption(Cola,[ListChbtId|ListaId]).

%funciona
systemAddChatbot(System1, Chatbot, System2):-
    getIDChatbot(Chatbot, IdChatbot)
    getChatbotSystem(System1,ListSystem),
    ListaId(ListSystem,ListIdlist),
    member(IdChatbot,ListIdlist),
    #f.
systemAddChatbot(System1, Chatbot, System2):-
    getIDChatbot(Chatbot, IdChatbot)
    getChatbotSystem(System1,ListSystem),
    ListaId(ListSystem,ListIdlist),
    \+member(IdChatbot,ListIdlist),
    setSystemChatbot(System1,[Chatbot|ListSystem], System2).
%funciona
user(NombreUser, ChatHistory,[NombreUser, ChatHistory]).

getChatHistoryUser(User, Chat):-
    system(_,Chat,User).

setChatHistoryUser(User,NewChat,NewUser):-
    system(Usuario,_,User).
    system(Usuario,NewChat,NewUser).

%funciona
getUserSystem(System, User):-
    system(User,_,_,_,_,System).
%funciona
setSystemUser(System,NewUser,NewSystem):-
    system(_, NameS, InitialChatbotCodeLinkS, ChatbotS, ChatHistoryS, System),
    system(NewUser, NameS, InitialChatbotCodeLinkS, ChatbotS, ChatHistoryS, NewSystem).
%funciona
systemAddUser(System, User, NewSystem):-
    getUserSystem(System, ListUsers),
    \+member(User,ListUsers),
    NewSystem = [User|System].
%funciona
systemLogin(System, User, SystemLogin):-
    getUserSystem(System, ListUsers),
    \+member(User,ListUsers),
    #f.
systemLogin(System, User, SystemLogin):-
    getUserSystem(System, ListUsers),
    member(User,ListUsers),
    NewListUsers = [User|ListUsers],
    setSystemUser(System, NewListUsers, SystemLogin).

%funciona pero no se que tan util sea
contarUsuario(_, [], 0).
contarUsuario(User, [User|Resto], Resultado) :-
    contarUsuario(User, Resto, ResultadoAnterior),
    Resultado is ResultadoAnterior + 1.
contarUsuario(User, [_|Resto], Resultado) :-
    contarUsuario(User, Resto, Resultado).

%funciona pero no se que tan util sea. talves haya que pasar como parametro User
esSystemaLogin(System) :-
    getUserSystem(System, ListUsers), % Asegúrate de que getUserSystem esté definido y funcione correctamente
    contarUsuario(_, ListUsers, Resultado), % Busca cualquier usuario en la lista
    Resultado == 2. % Verifica si se encontró al menos uno
/*pensar implementacion de fecha y hora, o juntalos */
chatHistory(Usuario, StringUser, Chatbot, StringChatbot, Fecha, Hora,[Usuario, StringUser, Chatbot, StringChatbot, Fecha, Hora]).

%funciona
systemLogout(System,SystemLogout):-
    getUserSystem(System, ListUsers),
    select(Primero, ListUsers, NewListUsers),
    setSystemUser(System,NewListUsers,SystemLogout).

(define s11 (system-talk-rec s10 "hola"))
(define s12 (system-talk-rec s11 "1"))
(define s13 (system-talk-rec s12 "1"))

listFlow([],ListaId).
listFlow([Cabeza|Cola],ListaId):-
    getFlowChatbot(Cabeza,ListFlowCh),
    listFlow(Cola,[ListFlowCh|ListaId]).

listOption([],ListaOpt).
listOption([Cabeza|Cola],ListaOpt):-
    getOptionFlow(Cabeza, ListaOptCabeza),
    listOption(Cola,[ListaOptCabeza|ListaOpt]).


listaKeywordMensajes(Option, Fusion):-
    getMensajeOption(Option, Mensaje),
    getKeywordOption(Option, ListK),
    Fusion = [Mensaje|ListK].

igualCaracter([], _, true).
igualCaracter([], [], true).
igualCaracter([Letra1|Resto1], [Letra2|Resto2]) :-
    (Letra1 == Letra2;
     esMayuscula(Letra1, Letra2);
     esMayuscula(Letra2, Letra1)),
    igualCaracter(Resto1, Resto2).

esMayuscula(LetraMinuscula, LetraMayuscula) :-
    char_code(LetraMinuscula, CodeMinuscula),
    char_code(LetraMayuscula, CodeMayuscula),
    CodeMayuscula is CodeMinuscula + 32.

listC(String, [Cabeza|Cola]) :-
    igualCaracter(String, Cabeza) == false,
    listC(String, Cola).
listC(String, [Cabeza|Cola]) :-
    igualCaracter(String, Cabeza) == true,
    listString(_, Cabeza, Respuesta).

listString(_, Cabeza, Cabeza).
listString(String, [Cabeza|ListaO], Respuesta) :-
    listaKeywordMensajes(Cabeza),
    listC(String, ListaCabeza),
    listString(String, ListaO, Respuesta).

modGetOpt([Option|ListaO], Ops, Rsp):-
    listaKeywordMensajes(Option, Fusion),
    +/member(Ops,Fusion),
    modGetOpt(ListaO, Ops, Rsp).
modGetOpt([Option|ListaO], Ops, Rsp):-
    listaKeywordMensajes(Option, Fusion),
    member(Ops,Fusion),
    modGetOpt(_, Option, Rsp).

/*Guardar los ids para poder reconocer el flujo y el chatbot*/
systemTalkRec(System, Mensaje, NewSystem):-
    esSystemaLogin(System, resultado),%arreglar resultado
    getChatbotSystem(System, Chatbot),
    listFlow(Chabot,Listaflow),
    listOption(Listaflow,ListaOpt), %si no funciona, hacer un respaldpo de la lista
    listString(Mensaje, ListaOpt, Rsp), %como esta la estrcutura completa, solo ocupar get, no hacer listas
    modGetOpt(ListaOpt, Rsp, OptUtil),
    getChatbotCodeLinkOption(OptUtil, Acc),
    getInitialFlowCodeLinkOption(OptUtil, Acc1),
    /*modificar nuevo flow y chatbot*/
    setFlowChatbot(Chatbot,NewFlow,NewChatbot):-
    chatbot(ChatbotIDC, NameC, WelcomeMessageC, StartFlowIdC, _,Chatbot),
    chatbot(ChatbotIDC, NameC, WelcomeMessageC, StartFlowIdC, NewFlow,NewChatbot).
    
    %setChatHistorySystem(System,NewChat,NewSystem).

vaciarLista([], Resultado).
vaciarLista([Lista|Cola], Resultado):-
    Acc = write(Lista),
    vaciarLista(Cola,[Acc|Resultado]).
/*Guardar los ids para poder reconocer el flujo y el chatbot*/
systemSynthesis(System, User, String):-
    esSystemaLogin(System, resultado),
    getChatHistorySystem(System, Chat),
    vaciarLista(Chat, String).
/*
myRandom(Xn, Xn1):-
    mulTemp is 1103515245 * Xn,
    sumTemp is mulTemp 12345,
    Xn1 is sumTemp mod 2147483648.

systemSimulate(System, InteraccionMax, NumAl):-
    NumUser = myRandom(NumAl,Respuesta),

**la implementacion de systemtalkrec es similar a la de chat history.
systemTalkRec(System, Mensaje, NewSystem):-
    esSystemaLogin(System, resultado),
    is_number(mensaje),
    getChatbotSystem(System, Chatbot),
    getFlowChatbot(Chatbot, Flow),
    getOptionFlow(Flow, Option),
    getMensajeOption(Option, MensajeOp)
    member(Mensaje, MensajeOp). %mensaje op es una lista de lista, comprobar que es lo que entrega
systemTalkRec(System, Mensaje, NewSystem):-
    esSystemaLogin(System, resultado),
    \+is_number(mensaje),
    getChatbotSystem(System, Chatbot),
    getFlowChatbot(Chatbot, Flow),
    getOptionFlow(Flow, Option),
    getKeywordOption(Option, ListKeywords),
    member(Mensaje, MensajeOp).
*/



