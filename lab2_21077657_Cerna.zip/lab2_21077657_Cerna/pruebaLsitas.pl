%Dominio: num x string x num x num x list(string) x option
%meta principal: option/6
option(CodeOp, Mensaje, ChatbotCodeLink, InitialFlowCodeLink, Keyword,[CodeOp, Mensaje, ChatbotCodeLink, InitialFlowCodeLink, Keyword]).

%Dominio: option x list(string)
%meta principal: getMensajeOption/2
getCodeOp([CodeOp, _, _, _, _], CodeOp).

%Dominio: option x list(string)
%meta principal: getMensajeOption/2
getMensajeOption([_, Mensaje, _, _, _], Mensaje).

%Dominio: option x list(string)
%meta principal: getKeywordOption/2
getKeywordOption([_, _, _, _, ListKeywords], ListKeywords).

%Dominio: option x num
%meta principal: getChatbotCodeLinkOption/2
getChatbotCodeLinkOption([_, _, ChatbotCodeLink, _, _], ChatbotCodeLink).

%Dominio: option x list
%meta principal: getInitialFlowCodeLinkOption/2
getInitialFlowCodeLinkOption([_, _, _, InitialFlowCodeLink, _], InitialFlowCodeLink).

/*.......................*/


listaId([], NewAcc, NewAcc).
listaId([Lista | Option], Acc, NewAcc) :-
    getCodeOp(Lista, CodeOp),
    listaId(Option, [CodeOp | Acc], NewAcc).


eliminar_elemento(_, [], []).
eliminar_elemento(X, [X | Resto], Resultado) :-
    eliminar_elemento(X, Resto, Resultado).
eliminar_elemento(X, [Y | Resto], [Y | Resultado]) :-
    X \= Y,
    eliminar_elemento(X, Resto, Resultado).


idRepetidos([], _, []).
idRepetidos(Lista, [Op | OpRest], [Op | R]) :-
    getCodeOp(Op, NewOp),
    member(NewOp, Lista),
    eliminar_elemento(NewOp,Lista,NewLista),
    idRepetidos(NewLista, OpRest, [Op|R]).
idRepetidos(Lista, [Op | OpRest], R) :-
    getCodeOp(Op, NewOp),
    \+ member(NewOp, Lista),
    idRepetidos(Lista, OpRest, R).

getOptionFlow([_, _, Option], Option).

flow(Id, NameMsg, Option, [Id, NameMsg, OpDef]):-
    listaId(Option, [], NwOption),
    list_to_set(NwOption, NewOp),
    idRepetidos(NewOp, Option, OpDef).

setOptionFlow(Flow,NewOption,FlowNew):-
    flow(IdF,NameMsgF,_,Flow),
    flow(IdF,NameMsgF,NewOption,FlowNew).

flowAddOption(Flow1,Option,Flow2):-
    getOptionFlow(Flow1, ListFlow1),
    getCodeOp(Option, OpO),
    \+member(OpO, ListFlow1),
    setOptionFlow(Flow1, [ListFlow1|Option],Flow2).
